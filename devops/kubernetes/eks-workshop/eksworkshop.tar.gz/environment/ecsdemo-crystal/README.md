![Build Status](https://codebuild.us-east-2.amazonaws.com/badges?uuid=eyJlbmNyeXB0ZWREYXRhIjoiS3laajZnV2dKQkdqUjNaNXB0Y0p2ZS8wcjVKMnltbFVPMmhQcVFaLzR3eEhlZk5pOEtaVkYrV05VM1BTUzFjb05ORjJzMEtmdHBjZ2RVWGpGN2RIdEVFPSIsIml2UGFyYW1ldGVyU3BlYyI6Ink2azhiRTNtUGFnTXN1N2UiLCJtYXRlcmlhbFNldFNlcmlhbCI6MX0%3D&branch=master)

# Amazon ECS Workshop

This is part of an Amazon ECS workshop at https://ecsworkshop.com
